// the configured options and settings for Tutorial
#define CMakeTutorial_VERSION_MAJOR 1
#define CMakeTutorial_VERSION_MINOR 0
#define USE_MYMATH

